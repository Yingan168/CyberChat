# Web-Chat-Application-Using-Encryption-Decryption-Tool
In this "Web Chat Application Using Encryption &amp; Decryption Tool" project , user have to enter the message to encode or decode. Users have to select the mode to choose the encoding and decoding process. The same key must be used to process the encoding and decoding for the same message.

# Message Encode - Decode:
Secure your Information by Encodng the messages. Encoding is the process that transforms the text or information to the unrecognizable form and decryption is the process to convert the encrypted message into original form.

# Meessage Encoding-Decoding:
Message encoding and decoding is the process to first convert the original text to the random and meaningless text called ciphertext. This process is called encoding. Decoding is the process to convert that ciphertext to the original text. This process is also called the Encryption-Decryption process.

# Project Summary:
In this "Web Chat Application Using Encryption & Decryption Tool" project , user have to enter the message to encode or decode. Users have to select the mode to choose the encoding and decoding process. The same key must be used to process the encoding and decoding for the same message.
![WhatsApp Image 2024-04-07 at 12 10 07_e4213447](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/5d69f591-8d97-43b3-bcba-

![WhatsApp Image 2024-04-07 at 12 10 09_ba5062d7](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/8b4810c2-d909-4c44-979d-b8f3f13be67e)
63389e73d3f1)

![WhatsApp Image 2024-04-07 at 12 10 09_2c3a60df](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/55f7231b-13c5-48a6-a6dc-155d84809d82)

![WhatsApp Image 2024-04-07 at 12 10 09_893a60e7](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/45e7b559-0267-40

![WhatsApp Image 2024-04-07 at 12 10 18_c4c70bb8](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/e39bc962-a995-477a-bfd0-0353b593f5f5)
2c-a5fb-8a70be0f4c57)

![WhatsApp Image 2024-04-07 at 12 10 18_dccc3fea](https://github.com/iamsuraj07/Web-Chat-Application-Using-Encryption-Decryption-Tool/assets/114692008/feb3b425-0e6c-4f52-b131-5307c3feba10)
